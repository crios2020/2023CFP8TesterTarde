//linea de comentarios
/* bloque de comentarios */

texto='Hola Mundo js!'
alert(texto)
console.log(texto);
document.getElementById("nro1").value='x'

document.getElementById("encabezado1").innerText="Aprendiendo JS"
document.getElementById("encabezado1").style=
                            "background-color: lightgray; border-radius: 15px;"

componente=document.getElementById("encabezado2")
componente.innerText="Hoy es viernes";
componente.style="background-color: lightgreen; border-radius: 15px;"

function verde(){
    console.log("se ejecuto la función verde")
    document.getElementById("contenedor").innerHTML="<p>Verde</p>"
    document.getElementById("contenedor").style="background-color: green;"
}

function rojo(){
    console.log("se ejecuto la función rojo")
    document.getElementById("contenedor").innerHTML="<p>Rojo</p>"
    document.getElementById("contenedor").style="background-color: red;"
}

function azul(){
    console.log("se ejecuto la función azul")
    document.getElementById("contenedor").innerHTML="<p>Azul</p>"
    document.getElementById("contenedor").style="background-color: blue;"
}

