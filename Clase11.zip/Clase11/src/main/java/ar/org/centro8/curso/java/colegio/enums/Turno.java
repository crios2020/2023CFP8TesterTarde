package ar.org.centro8.curso.java.colegio.enums;

public enum Turno {
    MAÑANA,
    TARDE,
    NOCHE
}
