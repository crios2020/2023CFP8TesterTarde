package ar.org.centro8.curso.java.colegio;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import ar.org.centro8.curso.java.colegio.utils.Calculadora;

@SpringBootTest
public class TestCalculadora {
    
    @Test
    public void pruebaEjemplo1(){
        assertEquals(1, 1);             //Green
    }

    @Test
    public void pruebaEjemplo2(){
        //assertEquals(1, 2);             //Red
    }

    @Test
    public void pruebaSumar1(){
        assertEquals(Calculadora.sumar(2,2), 4);            
    }

    @Test
    public void pruebaSumar2(){
        assertEquals(Calculadora.sumar(20,-2), 18);            
    }

    @Test
    public void pruebaParametrosNoEntero01(){
        assertEquals(Calculadora.sumar(10,10.0), 20);            
    }

}
