package ar.org.centro8.curso.java.colegio.test;

import ar.org.centro8.curso.java.colegio.utils.Calculadora;

public class TestCalculadora {
    public static void main(String[] args) {
        
        //Test por objectos MOCKS
        
        System.out.println(Calculadora.sumar(2, 2));        //4
        System.out.println(Calculadora.restar(26, 23));     //3
    }
}
