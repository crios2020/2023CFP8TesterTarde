package ar.org.centro8.curso.java.colegio.test;

import ar.org.centro8.curso.java.colegio.entities.Alumno;
import ar.org.centro8.curso.java.colegio.entities.Curso;
import ar.org.centro8.curso.java.colegio.enums.Dia;
import ar.org.centro8.curso.java.colegio.enums.Turno;
import ar.org.centro8.curso.java.colegio.repositories.AlumnoRepository;
import ar.org.centro8.curso.java.colegio.repositories.CursoRepository;

public class TestRepository {
   public static void main(String[] args) {
        CursoRepository cr=new CursoRepository();

        Curso curso=new Curso("<h1>java</h1>","Rios;",Dia.MIERCOLES,Turno.NOCHE);

        cr.save(curso);

        System.out.println(curso);

        cr.getAll().forEach(System.out::println);
        System.out.println("******************************");
        System.out.println(cr.getById(40));
        System.out.println("******************************");
        cr.getLikeTitulo("ja").forEach(System.out::println);

        AlumnoRepository ar=new AlumnoRepository();
        Alumno alumno=new Alumno("Juan","Lozano",34,40);
        ar.save(alumno);
        System.out.println(alumno);

        System.out.println("******************************");
        ar.getAll().forEach(System.out::println);
        System.out.println("******************************");
        System.out.println(ar.getById(16));
        System.out.println("******************************");
        ar.getLikeApellido("ri").forEach(System.out::println);
        
   } 
}
