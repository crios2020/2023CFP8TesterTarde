package ar.org.centro8.curso.java.colegio.utils;

/*
 *  TDD Test Development Drive
 *      Desarrollo de software en base a pruebas
 * 
 * Comentarios TODO marcan tareas pendientes
 * 
 * comentarios JavaDOC pueden verse desde fuera del programa binario
 * 
 */

/**
 * Programa calculadora
 */
public class Calculadora {
    
    /**
     * Este método suma los parámetros de entrada
     * @param nro1  parámetro1 
     * @param nro2  parámetro2
     * @return  suma de nro1 y nro2
     */
    public static double sumar(double nro1, double nro2){
        //TODO Sumar los parámetros de entrada
        return nro1+nro2;
    }

    /**
     * Este método resta los parámetros de entrada
     * @param nro1  parámetro1 
     * @param nro2  parámetro2
     * @return  resta de nro1 y nro2
     */
    public static double restar(double nro1, double nro2){
        //TODO Restar los parámetros de entrada
        return 0;
    }

    /**
     * Este método divide los parámetros de entrada
     * @param nro1  parámetro1 
     * @param nro2  parámetro2
     * @return  división de nro1 y nro2
     */
    public static double dividir(double nro1, double nro2){
        //TODO Dividir los parámetros de entrada
        return 0;
    }

    /**
     * Este método multiplica los parámetros de entrada
     * @param nro1  parámetro1 
     * @param nro2  parámetro2
     * @return  multiplicación de nro1 y nro2
     */
    public static double multiplicar(double nro1, double nro2){
        //TODO Multiplicar los parámetros de entrada
        return 0;
    }

}
