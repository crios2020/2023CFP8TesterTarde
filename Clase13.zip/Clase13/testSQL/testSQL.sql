use colegio;

-- registro valido
INSERT INTO cursos (titulo, profesor, dia, turno)
VALUES ('Matemáticas', 'Juan Pérez', 'LUNES', 'MAÑANA');			-- ok

-- registro invalido caracteres no permitidos <>
INSERT INTO cursos (titulo, profesor, dia, turno)
VALUES ('<h1>Mate</h1>', 'Juan Pérez', 'LUNES', 'MAÑANA');			-- error

-- registro invalido caracteres no permitidos ;
INSERT INTO cursos (titulo, profesor, dia, turno)
VALUES ('Matemáticas', 'Juan Pérez;', 'LUNES', 'MAÑANA');			-- error

-- registro invalido días no permitidos
INSERT INTO cursos (titulo, profesor, dia, turno)
VALUES ('Matemáticas', 'Juan Pérez', 'LUNE', 'MAÑANA');				-- OK

-- registro invalido días no permitidos
INSERT INTO cursos (titulo, profesor, dia, turno)
VALUES ('Matemáticas', 'Juan Pérez', 'OSVALDO', 'MAÑANA');			-- OK

-- registro invalido días no permitidos
INSERT INTO cursos (titulo, profesor, dia, turno)
VALUES ('Matemáticas', 'Juan Pérez', 'LUN3S', 'MAÑANA');			-- OK

-- registro invalido días no permitidos
INSERT INTO cursos (titulo, profesor, dia, turno)
VALUES ('Matemáticas', 'Juan Pérez', 35, 'MAÑANA');					-- OK

-- registro invalido turnos no permitidos
INSERT INTO cursos (titulo, profesor, dia, turno)
VALUES ('Matemáticas', 'Juan Pérez', 'LUNES', 'MANIANA');			-- OK

select * from cursos;