package ar.org.centro8.curso.java.colegio.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import ar.org.centro8.curso.java.colegio.entities.Alumno;
import ar.org.centro8.curso.java.colegio.entities.Curso;
import ar.org.centro8.curso.java.colegio.repositories.AlumnoRepository;
import ar.org.centro8.curso.java.colegio.repositories.CursoRepository;

@Controller
public class WebController {
    
    private CursoRepository cursoRepository=new CursoRepository();
    private AlumnoRepository alumnoRepository=new AlumnoRepository();
    private String mensajeCurso="Ingrese un nuevo Curso!";
    private String mensajeAlumno="Ingrese un nuevo Alumno!";

    @GetMapping("/")
    public String getIndex(){
        return "index";
    }

    @GetMapping("/cursos")
    public String getCursos(@RequestParam(name="buscarTitulo", required = false, defaultValue="") String buscarTitulo,
                                 Model model){
        model.addAttribute("mensajeCurso", mensajeCurso);
        model.addAttribute("curso", new Curso());
        //model.addAttribute("cursos", cursoRepository.getAll());
        model.addAttribute("likeTitulo", cursoRepository.getLikeTitulo(buscarTitulo));
        return "cursos";
    }

    @GetMapping("/alumnos")
    public String getAlumnos(@RequestParam(name="buscarApellido", required = false, defaultValue="") String buscarApellido,
                    Model model){
        model.addAttribute("mensajeAlumno", mensajeAlumno);
        model.addAttribute("alumno", new Alumno());
        model.addAttribute("likeApellido", alumnoRepository.getLikeApellido(buscarApellido));
        model.addAttribute("cursos", cursoRepository.getAll());
        return "alumnos";
    }

    @PostMapping("/saveCurso")
    public String save(@ModelAttribute Curso curso){
        try {
            cursoRepository.save(curso);
            mensajeCurso="Se guardo el curso id: "+curso.getId();
        } catch (Exception e) {
            mensajeCurso="Ocurrio un error";
        }
        return "redirect:cursos";
    }

    @PostMapping("/saveAlumno")
    public String save(@ModelAttribute Alumno alumno){
        try {
            alumnoRepository.save(alumno);
            mensajeAlumno="Se guardo el alumno id: "+alumno.getId();
        } catch (Exception e) {
            mensajeAlumno="Ocurrio un error";
        }
        return "redirect:alumnos";
    }
}
